Patch by Shoozza to use TNT with Delphi Personal Edition (without DB components)
* https://github.com/Shoozza/TNT-Unicode-Controls

Patch by Gilles Arcas to use TNT with Delphi Personal Edition (without MnuBuild)
* check "///" in TntMenus_Design.pas
* Tnt menu designer should not work however Drago uses SpTBX menu component.


 