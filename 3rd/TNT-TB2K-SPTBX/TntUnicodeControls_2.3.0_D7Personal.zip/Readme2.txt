Patch by Shoozza to use TNT with Delphi Personal Edition (without DB components)
* https://github.com/Shoozza/TNT-Unicode-Controls

Patch by Gilles Arcas to use TNT with Delphi Personal Edition
* add vcldesigner in requires list in TntUnicodeVcl_D70.dpk (otherwise MnuBuild not available)
* add TTntHeaderControl
